KASIR BRJ V12 - PWA
Paket PWA siap untuk hosting HTTPS.
File utama: index.html, manifest.webmanifest, service-worker.js, icon-192.png, icon-512.png.
PIN awal: 1234.
Setelah online HTTPS, URL aplikasi dapat dipakai di PWABuilder untuk proses APK.
